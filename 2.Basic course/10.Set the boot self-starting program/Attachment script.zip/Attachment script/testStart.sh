#!/bin/sh
touch /home/pi/hello.c
sudo chmod 777 /home/pi/hello.c
echo "hello word!">>/home/pi/hello.c
